#!/bin/bash
docker build -t "scalyr/scalyr-k8s-agent:2.0.38.pre39.5" -f .
